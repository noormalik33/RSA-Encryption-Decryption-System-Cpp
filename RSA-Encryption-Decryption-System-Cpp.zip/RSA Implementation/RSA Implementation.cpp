#include <iostream>
#include <cmath>
using namespace std;

// Function to calculate gcd (Greatest Common Divisor) using Euclid's Algorithm
int gcd (int a, int b)
{
    if (b == 0)
    {
        return a;
    }
    
    return gcd (b, a % b);
}
// Function to calculate modular exponentiation (a^b mod m)
int modExp (int base, int exponent, int modulus)
{
    int result = 1;
    base = base % modulus;
    
    while (exponent > 0) 
	{
        if (exponent % 2 == 1)
        {
            result = (result * base) % modulus; 
		}
		
        exponent = exponent >> 1;
        base = (base * base) % modulus;
    }
    
    return result;
}

// Function to find modular multiplicative inverse using Extended Euclidean Algorithm
int modInverse(int a, int m) 
{
    int m0 = m;
    int y = 0, x = 1;
    
    if (m == 1)
    {
        return 0;
    }
    
    while (a > 1) 
	{
        int q = a / m;
        int t = m;
        m = a % m, a = t;
        t = y;
        y = x - q * y;
        x = t;
    }
    
    if (x < 0)
    {
        x += m0;
    }
    
    return x;
}

// Function to generate RSA keys
void generateKeys (int p, int q, int &n, int &e, int &d, int &phiN) 
{
    // Compute n
    n = p * q;

    // Compute Euler's totient function f(n)
    phiN = (p - 1) * (q - 1);

    // Choose e such that 1 < e < f(n) and gcd(e, f(n)) = 1
    e = 2; // Start with a small prime number
    
    while (e < phiN) 
	{
        if (gcd(e, phiN) == 1)
        {
            break;
        }
        
        e++;
    }

    // Compute d as the modular multiplicative inverse of e modulo f(n)
    d = modInverse(e, phiN);
}

// Function to check if a number is prime
bool isPrime (int n) 
{
    if (n <= 1)
    {
        return false;
    }
    
    if (n <= 3)
    {
        return true;
    }
    
    if (n % 2 == 0 || n % 3 == 0)
    {
        return false;
    }
    
    for (int i = 5; i * i <= n; i += 6) 
	{
        if (n % i == 0 || n % (i + 2) == 0)
        {
            return false;
        }
    }
    return true;
}

int main() 
{
    int x;
    
    cout<<"------------------------------------------------------------------";
    
	cout << "\n\nEnter a number (for checking if number is prime or composite): ";
    cin >> x;

    if ( isPrime (x) ) 
	{
        cout << "\n\n\t";
		cout << x << " is a prime number." << endl;

        // Implement RSA with the prime number
        int n, e, d, phiN;
        
        generateKeys (x, x, n, e, d, phiN);

        // Public key (e, n)
        cout << "\n\tPublic Key (e, n): (" << e << ", " << n << ")" << endl;

        // Private key (d, n)
        cout << "\tPrivate Key (d, n): (" << d << ", " << n << ")" << endl;

        cout << "\n\nEuler's Totient Function f(" << n << "): " << phiN << endl;

        int message;
        
        cout << "\nEnter the message to be encrypted: ";
        cin >> message;

        // Encryption
        int ciphertext = modExp (message, e, n);
        
        cout << "\n\n\tEncrypted Message: " << ciphertext << endl;

        // Decryption
        int decryptedMessage = modExp (ciphertext, d, n);
        
        cout << "\tDecrypted Message: " << decryptedMessage << endl << endl;
        cout << "\n------------------------------------------------------------------" << endl << endl << endl << endl;
    } 
    
	else 
	{
		cout << "\n\n\t";
		cout << x << " is a composite number." << endl;

        // Implement RSA with composite number
        // For demonstration, you can choose any arbitrary prime numbers here
        int p, q;
        
        cout << "\n\n\tEnter the value of p: ";
        cin >> p;
        
        cout << "\tEnter the value of q: ";
        cin >> q;
        
        int n, e, d, phiN;
        
        generateKeys(p, q, n, e, d, phiN);

        // Public key (e, n)
        cout << "\n\tPublic Key (e, n): (" << e << ", " << n << ")" << endl;

        // Private key (d, n)
        cout << "\tPrivate Key (d, n): (" << d << ", " << n << ")" << endl;

        cout << "\n\nEuler's Totient Function f(" << n << "): " << phiN <<endl;
        

        int message;
        
        cout << "\n\nEnter the message to be encrypted: ";
        cin >> message;

        // Encryption
        int ciphertext = modExp(message, e, n);
        
        cout << "\n\n\tEncrypted Message: " << ciphertext << endl;

        // Decryption
        int decryptedMessage = modExp(ciphertext, d, n);
        
        cout << "\tDecrypted Message: " << decryptedMessage << endl << endl;
        
        cout<<"\n------------------------------------------------------------------" <<endl << endl << endl;
    }

    return 0;
}